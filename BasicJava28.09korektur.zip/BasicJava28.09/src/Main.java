public class Main {
    public static void main(String[] args) {
    System.out.println("Hello world!");
    char c = 'G';
    int i = 89;
    byte b = 4;
    short s = 56;
    float f = 4.7333436F;
    double d = 4.355453532;
    long l = 12121L;
    System.out.println(c);
    System.out.println(i);
    System.out.println(b);
    System.out.println(s);
    System.out.println(f);
    System.out.println(d);
    System.out.println(l);

    /*
    Дано трехзначное число. Вывести на экран все цифры этого числа
Пример: 345
Вывод в консоль: Число 345 -> 3, 4, 5
Другой пример: 987
Вывод в консоль: Число 987 -> 9, 8, 7
     */
        int number = 345;
        int n1 = number / 100;
        int n2 = number % 100 / 10;
        int n3 = number % 10;
        System.out.println("345" + number + " -> " +n1 + " , " + n2 + " , " + n3);

        int nr = 987;
        int nm1 = nr / 100;
        int nm2 = nr % 100 / 10;
        int nm3 = nr % 10;
        System.out.println("987" + nr + " -> " + nm1 + " , " + nm2 + " , " + nm3);



}}